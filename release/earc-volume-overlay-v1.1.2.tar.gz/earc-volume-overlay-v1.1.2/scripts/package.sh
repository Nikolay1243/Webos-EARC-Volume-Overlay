#!/bin/sh
set -eu

cd "$(dirname "$0")/.."

VERSION=$(sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' app/appinfo.json | head -n 1)
[ -n "$VERSION" ] || { echo "Could not read app version" >&2; exit 1; }

mkdir -p build
rm -f build/org.webosbrew.earcvolume_*_all.ipk
npx ares-package app --no-minify -o build

IPK="build/org.webosbrew.earcvolume_${VERSION}_all.ipk"
[ -f "$IPK" ] || { echo "Expected package was not created: $IPK" >&2; exit 1; }
echo "Packaged $IPK"
