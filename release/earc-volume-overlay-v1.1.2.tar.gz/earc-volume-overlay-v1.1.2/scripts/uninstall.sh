#!/bin/sh
set -eu

: "${TV_HOST:?Set TV_HOST, for example root@TV_IP_ADDRESS}"

ssh_tv() {
	if [ -n "${TV_SSH_KEY:-}" ]; then
		ssh -i "$TV_SSH_KEY" -o StrictHostKeyChecking=accept-new "$TV_HOST" "$@"
	else
		ssh -o StrictHostKeyChecking=accept-new "$TV_HOST" "$@"
	fi
}

ssh_tv 'RUNTIME=/var/lib/earc-volume-overlay
PIDFILE=$RUNTIME/watcher.pid
if [ -f "$PIDFILE" ]; then
	pid=$(cat "$PIDFILE" 2>/dev/null || true)
	if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
		cmd=$(tr "\000" " " < "/proc/$pid/cmdline" 2>/dev/null || true)
		case "$cmd" in *"$RUNTIME/watcher.js"*) kill "$pid" 2>/dev/null || true;; esac
	fi
fi
rm -f /var/lib/webosbrew/init.d/91-earc-volume-overlay
rm -rf /var/lib/earc-volume-overlay
luna-send -n 1 luna://com.webos.appInstallService/dev/remove '"'"'{"id":"org.webosbrew.earcvolume"}'"'"' >/dev/null 2>&1 || true
echo "eARC Volume Overlay removed"'
