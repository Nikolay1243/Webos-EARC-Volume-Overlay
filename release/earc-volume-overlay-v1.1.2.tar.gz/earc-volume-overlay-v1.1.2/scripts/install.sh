#!/bin/sh
set -eu

cd "$(dirname "$0")/.."

: "${TV_HOST:?Set TV_HOST, for example root@TV_IP_ADDRESS}"
APP_ID=org.webosbrew.earcvolume
REMOTE_IPK=/tmp/earc-volume-overlay.ipk
REMOTE_WATCHER=/tmp/earc-volume-watcher.js
REMOTE_INIT=/tmp/91-earc-volume-overlay

ssh_tv() {
	if [ -n "${TV_SSH_KEY:-}" ]; then
		ssh -i "$TV_SSH_KEY" -o StrictHostKeyChecking=accept-new "$TV_HOST" "$@"
	else
		ssh -o StrictHostKeyChecking=accept-new "$TV_HOST" "$@"
	fi
}

scp_tv() {
	if [ -n "${TV_SSH_KEY:-}" ]; then
		scp -i "$TV_SSH_KEY" -o StrictHostKeyChecking=accept-new "$1" "$TV_HOST:$2"
	else
		scp -o StrictHostKeyChecking=accept-new "$1" "$TV_HOST:$2"
	fi
}

IPK=$(ls build/org.webosbrew.earcvolume_*_all.ipk 2>/dev/null | head -n 1 || true)
if [ -z "$IPK" ]; then
	[ -d node_modules ] || npm install
	npm run package
	IPK=$(ls build/org.webosbrew.earcvolume_*_all.ipk | head -n 1)
fi

echo "Copying app and watcher to $TV_HOST..."
scp_tv "$IPK" "$REMOTE_IPK"
scp_tv runtime/watcher.js "$REMOTE_WATCHER"
scp_tv runtime/91-earc-volume-overlay "$REMOTE_INIT"

echo "Installing $APP_ID..."
if [ -n "${TV_SSH_KEY:-}" ]; then
	ssh -tt -i "$TV_SSH_KEY" -o StrictHostKeyChecking=accept-new "$TV_HOST" \
		"luna-send -w 60000 -i luna://com.webos.appInstallService/dev/install '{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\"$REMOTE_IPK\",\"subscribe\":true}' | grep -oE '\"state\":\"[^\"]*\"|\"errorText\":\"[^\"]*\"' | uniq"
	else
	ssh -tt -o StrictHostKeyChecking=accept-new "$TV_HOST" \
		"luna-send -w 60000 -i luna://com.webos.appInstallService/dev/install '{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\"$REMOTE_IPK\",\"subscribe\":true}' | grep -oE '\"state\":\"[^\"]*\"|\"errorText\":\"[^\"]*\"' | uniq"
fi

echo "Installing and starting the root-side watcher..."
ssh_tv 'set -e
RUNTIME=/var/lib/earc-volume-overlay
PIDFILE=$RUNTIME/watcher.pid
if [ -f "$PIDFILE" ]; then
	pid=$(cat "$PIDFILE" 2>/dev/null || true)
	if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
		cmd=$(tr "\000" " " < "/proc/$pid/cmdline" 2>/dev/null || true)
		case "$cmd" in *"$RUNTIME/watcher.js"*) kill "$pid" 2>/dev/null || true;; esac
	fi
fi
mkdir -p "$RUNTIME" /var/lib/webosbrew/init.d
cp /tmp/earc-volume-watcher.js "$RUNTIME/watcher.js"
cp /tmp/91-earc-volume-overlay /var/lib/webosbrew/init.d/91-earc-volume-overlay
chmod 644 "$RUNTIME/watcher.js"
chmod 755 /var/lib/webosbrew/init.d/91-earc-volume-overlay
rm -f "$PIDFILE" /tmp/earc-volume-overlay.ipk /tmp/earc-volume-watcher.js /tmp/91-earc-volume-overlay
/var/lib/webosbrew/init.d/91-earc-volume-overlay'

echo "Installed. Log: /tmp/earc-volume-overlay.log"
