# eARC Volume Overlay for LG webOS

A small on-screen volume indicator for rooted LG webOS TVs connected to an
eARC/ARC soundbar or receiver. It restores the numeric volume display that LG's
built-in UI often omits for externally controlled audio devices.

The overlay is intentionally minimal: a large number in the bottom-right corner.
It updates while visible and disappears about two seconds after the final volume
change.

## Features

- Reads live volume and mute changes from `com.webos.service.audio`
- Activates only while the current sound output is `external_arc`
- Updates the existing overlay instead of opening duplicate windows
- Resets its hide timer after every volume change
- Runs automatically after boot through the Homebrew Channel init directory
- Does not replace or interrupt the foreground app

## Requirements

- A rooted LG webOS TV
- Homebrew Channel installed
- SSH access as `root`
- `/usr/bin/node`, `/usr/bin/luna-send`, and `/usr/bin/script` on the TV
- An ARC/eARC device that reports a numeric volume through webOS

Not every HDMI-CEC receiver reports an absolute volume. If webOS only receives
volume-up/down acknowledgements, this project cannot infer the real number.

## Build

Install Node.js 18 or newer on your computer, then run:

```sh
npm install
npm run package
```

The IPK is written to `build/`.

## Install on a rooted TV

The web app and root-side watcher are both required. Set the TV address and,
optionally, the SSH private key:

```sh
TV_HOST=root@TV_IP_ADDRESS \
TV_SSH_KEY="/path/to/your/private_key" \
sh scripts/install.sh
```

If your SSH config already defines the identity, omit `TV_SSH_KEY`.

The installer packages the app if needed, installs its IPK through the webOS
developer install service, deploys the watcher under
`/var/lib/earc-volume-overlay`, and adds the startup hook at
`/var/lib/webosbrew/init.d/91-earc-volume-overlay`.

## Uninstall

```sh
TV_HOST=root@TV_IP_ADDRESS \
TV_SSH_KEY="/path/to/your/private_key" \
sh scripts/uninstall.sh
```

## Logs

On the TV:

```sh
tail -f /tmp/earc-volume-overlay.log
```

A healthy startup looks similar to:

```text
service starting
watching external_arc at 12:false
```

## How it works

The root-side Node.js watcher subscribes to the webOS master-volume service.
When the numeric ARC/eARC volume changes, it launches or relaunches the hidden
overlay app with the new value. The transparent web app handles the
`webOSRelaunch` event, updates the number in place, and closes itself after its
short timeout.

## Customisation

The overlay layout and timeout are plain HTML/CSS/JavaScript in
`app/index.html`. After editing it, increment the version in both
`app/appinfo.json` and `package.json`, then rebuild and reinstall.

## Safety

This is unofficial software for rooted TVs. Firmware updates can change private
webOS services or remove root access. Keep a known recovery path for your TV and
review scripts before running them.

## Licence

MIT
